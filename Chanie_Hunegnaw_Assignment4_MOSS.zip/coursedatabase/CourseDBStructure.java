package coursedatabase;
/**
 * this program is implements the course dat abse structure interface class
 * of the hash code
 *@author hunegnaw
 *
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface
{

	LinkedList<CourseDBElement>[] hashTable;
	int tablesize ;
	int size;

	public CourseDBStructure(int size1)
	{
		this.size = 0;
		this.tablesize = size1;
		hashTable=new LinkedList[size1];
	}
/**
 * constructor for CourseDBStructure
 * @param s for size
 * @param size1 for integer size
 */
	public CourseDBStructure(String s, int size1)
	{
		this.size = 0;
		this.tablesize = size1;
		hashTable=new LinkedList[size1];
	}


/**
 * override 
 * add the course element
 */
	@Override
	public void add(CourseDBElement element)
	{
		int hash =element.hashCode()%getTableSize();

		if(hashTable[hash]!=null){
		hashTable[hash].add(element);}
		else
		{
			hashTable[hash]=new LinkedList<CourseDBElement>();
			hashTable[hash].add(element);
		}
	}
/**
 * get method for the CourseDB element
 * @return the value
 */
	@Override
	public CourseDBElement get(int crn) throws IOException
	{
		for(int j=0;j<getTableSize();j++)
		{
			if(hashTable[j]==null)
				continue;

			LinkedList<CourseDBElement> list=hashTable[j];
			for(int i=0;i<list.size();i++)
			{
				if(list.get(i).CRN==crn)
				{
					return list.get(i);
				}
			}
		}
		throw new IOException();
	}

/**
 * get method for the table size
 * @return table size
 */

	@Override
	public int getTableSize()
	{
		return tablesize;
	}
	/**
	 * arraylist show method and create an object of CourseDBElement
	 * @return an arry of hash code
	 */

	public ArrayList<String> showAll()
	{
		CourseDBElement cde = new CourseDBElement();

		ArrayList<String> array = new ArrayList<String>();
		for(int i = 0; i < getTableSize(); i++)
		{
			if(hashTable[i] != null)
			{
				LinkedList<CourseDBElement> list=hashTable[i];
				for(CourseDBElement next : list)
				{
					String cdeString = "\n" + next;
					array.add(cdeString);
				}
			}
		}
		return array;
	}


}



