package coursedatabase;
/**
 * the manager class implements the CourseDBManagerInterface
 * 
 * @author hunegnaw
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface
{
	CourseDBStructure cds = new CourseDBStructure(20);
	CourseDBElement cde = new CourseDBElement();
/**
 * add methd that overrides the 
 */
	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor)
	{
		CourseDBElement cde = new CourseDBElement(id, crn, credits, roomNum, instructor);
		cds.add(cde);
	}
/**
 * getter of crn
 */
	@Override
	public CourseDBElement get(int crn)
	{
		try {
			return cds.get(crn);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
/**
 * read file method that ovrrides and read the file 
 */
	@Override
	public void readFile(File input) throws FileNotFoundException
	{
		String courseId = "", stringCrn = "",  stringCredits = "", room = "", instructor = "";
		int crn, credits;
		
		Scanner scanner = new Scanner(input);
		
		while(scanner.hasNext()) {
			
			if(scanner.hasNext()) {
				courseId = scanner.next();
			}
			if(scanner.hasNext()) {
				stringCrn = scanner.next();
			}
			crn = Integer.parseInt(stringCrn);
			
			if(scanner.hasNext()) {
				stringCredits = scanner.next();
			}
			credits = Integer.parseInt(stringCredits);
			
			if(scanner.hasNext()){
				room = scanner.next();
			}
			
			if(scanner.hasNext()) {
				instructor = scanner.nextLine();
			}
			
			add(courseId,crn,credits,room,instructor);	
		}
		
		scanner.close();
	}

	@Override
	public ArrayList<String> showAll()
	{
		return cds.showAll();
	}
}

	



