package coursedatabase;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CourseDBManager_STUDENT_Test {

	private CourseDBManagerInterface dataMg = new CourseDBManager();

	/**
	 * Create an instance of CourseDBManager
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		dataMg = new CourseDBManager();
	}

	/**
	 * Set dataMg reference to null
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {
		dataMg = null;
	}

	/**
	 * Test for the add method
	 */
	@Test
	public void testAddToDB() {
		try {
			dataMg.add("CMSC140",30504,3,"SC450","Joey Bag-O-Donuts");
		}
		catch(Exception e) {
			fail("This should not have caused an Exception");
		}
	}
	
	/**
	 * Test for the showAll method
	 */
	@Test
	public void testShowAll() {
		dataMg.add("CMSC140",30504,3,"SC450","Joey Bag-O-Donuts");
		dataMg.add("CMSC140",30503,3,"SC450","Jill B. Who-Dunit");
		dataMg.add("CMSC204",30559,4,"SC450","BillyBob Jones");
		ArrayList<String> list = dataMg.showAll();
		
		assertEquals(list.get(0),"\nCourse:CMSC140 CRN:30503 Credits:3 Instructor:Jill B. Who-Dunit Room:SC450");
		assertEquals(list.get(1),"\nCourse:CMSC140 CRN:30504 Credits:3 Instructor:Joey Bag-O-Donuts Room:SC450");
		assertEquals(list.get(2),"\nCourse:CMSC204 CRN:30559 Credits:4 Instructor:BillyBob Jones Room:SC450");
			}
	/**
	 * Test for the read method
	 */
	@Test
	public void testRead() {
		try {
			File inputFile = new File("Test1.txt");
			PrintWriter inFile = new PrintWriter(inputFile);
			inFile.println("CMSC140 30504 3 SC450 Joey Bag-O-Donuts");
			inFile.print("CMSC140 30503 3 SC450 Jill B. Who-Dunit");
			
			inFile.close();
			dataMg.readFile(inputFile);
			//System.out.println(dataMgr.showAll());
		} catch (Exception e) {
			fail("Should not have thrown an exception");
		}
	}
}
