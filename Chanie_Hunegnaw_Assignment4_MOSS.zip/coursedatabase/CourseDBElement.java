package coursedatabase;
/**
 * this class implements the camparable interface 
 * for the database of student course 
 * @author hunegnaw
 *
 */

public class CourseDBElement implements Comparable
{
	int CRN;
	int numCredits;
	String roomNum;
	String instructorName;
	String hashcod;
	String courseID;
	public String getCourseID() {
		return courseID;
	}
	/**
	 * set the course id
	 * @param courseID
	 */

	public void setCourseID(String courseID) {
		this.courseID = courseID;
	}
/**
 * getter for CRN
 * @return the crn number
 */
	public int getCRN() {
		return CRN;
	}

	/**
	 * setter for CRN
	 * @param crn
	 */
	public void setCRN(int crn) {
		this.CRN = crn;
	}
	/**
	 * getter for number of credits
	 * @return NumCredits
	 */

	public int getNumCredits() {
		return numCredits;
	}
/**
 * setter for number of credits
 * @param numCredits
 */
	public void setNumCredits(int numCredits) {
		this.numCredits = numCredits;
	}
/**
 * getter room number
 * @return room number
 */
	public String getRoomNum() {
		return roomNum;
	}

	/**
	 * setter for room number
	 * @param roomNum
	 */
	public void setRoomNum(String roomNum) {
		this.roomNum = roomNum;
	}
/**
 * getter instructors name
 * @return name of string
 */
	public String getInstructorName() {
		return instructorName;
	}

	/**
	 * setter of string name of instructor
	 * @param instructorName
	 */
	public void setInstructorName(String instructorName) {
		this.instructorName = instructorName;
	}

/**
 *  default constructor course data element
 * 
 */
	public CourseDBElement()
	{
		courseID = null;
		CRN = 0;
		numCredits = 0;
		roomNum = null;
		instructorName = null;
		this.hashcod=hashcode();
	}
/**
 * constructor of course data element
 * @param courseID
 * @param CRN
 * @param numCredits
 * @param roomNum
 * @param instructorName
 */
	public CourseDBElement(String courseID,int CRN,int numCredits,String roomNum,String instructorName)
	{
		this.courseID = courseID;
		this.CRN = CRN;
		this.numCredits = numCredits;
		this.roomNum = roomNum;
		this.instructorName = instructorName;
		this.hashcod=hashcode();
	}
/**
 * string method to pring a set of strings
 */
	
	public String toString()
	{
		String str = ("Course:"+courseID
					+" CRN:"+CRN
					+" Credits:"+numCredits
					+" Instructor:"+instructorName
					+" Room:"+roomNum);
		return str;
	}
/**
 * hash code method
 * @return strign of code
 */


	public String hashcode()
	{
		return ""+((""+CRN).hashCode());
	}
/**
 * comparse method that override the 
 * and compares to course data base of the element
 */
	@Override
	public int compareTo(CourseDBElement element)
	{
		if(CRN < element.CRN)
			return -1;
		else if(CRN > element.CRN)
			return 1;
		else
			return 0;
	}

}
